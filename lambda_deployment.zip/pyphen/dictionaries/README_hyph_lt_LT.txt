Hyphenation dictionary for Lithuanian
=====================================

You're looking at the hyphenation tables for OpenOffice for
Lithuanian.

Language: Lithuanian (lt_LT)
Origin: TeX hyphenation tables by Sigitas Tolusis and Vytas
        Statulevicius.  The original tables can be found at
        http://www.vtex.lt/tex/download/zip/texmf.zip as lthyphen.tex.
Author: Converted to OOo format by Albertas Agejevas <alga@akl.lt>
License: LaTeX Project Public Licence

To enable hyphenation for Lithuanian in OpenOffice, go to
Tools->Options->Language settings->Writing Aids and maybe set
Tools->Options->Language settings->Languages->Western->Lithuanian.

Then, enable hyphenation in chosen paragraphs by checking
Format->Paragraph->Text Flow->Hyphenation->Automatically.
